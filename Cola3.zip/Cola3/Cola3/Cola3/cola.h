#pragma once
#define N 25

class cola
{
private:
	int frente;
	int final;
	int V[N];
public:
	cola(void);
	void encolar(int x);
	int desencolar();
	bool lleno();
	bool vacio();
};

