#include "StdAfx.h"
#include "cola.h"


cola::cola(void)
{
	frente=0;
	final=-1;
}
void cola::encolar(int x)
{
	V[++final]=x;
}
int cola::desencolar()
{
	int aux;
	aux=V[frente++];
	return aux;
}
bool cola::lleno()
{
	if(final==N-1)
		return true;
	else
		return false;
}
bool cola::vacio()
{
	if(final==-1)
		return true;
	else
		return false;
}