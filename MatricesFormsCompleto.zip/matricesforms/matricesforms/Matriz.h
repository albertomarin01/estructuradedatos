#pragma once
#define N 5
class Matriz
{
private:
	int M[N][N];
	int filas;
	int columnas;
public:
	Matriz(void);
	void insertar(int a, int x, int y);
	int mostrar(int x, int y);
	void setf(int x);
	void setc(int x);
	int getf();
	int getc();
	int SumaTotal(int x, int y);
	int Diagonal(int x, int y);
	int Factorial(int x, int y);
	bool pares(int x, int y);
};

