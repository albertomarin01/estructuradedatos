#include "StdAfx.h"
#include "Matriz.h"


Matriz::Matriz(void)
{
	filas=0;
	columnas=0;
}
void Matriz::insertar(int a, int x, int y){
	M[x][y]=a;
}
int Matriz::mostrar(int x, int y){
return M[x][y];
}
void Matriz::setf(int x){
filas=x;
}
void Matriz::setc(int x){
columnas=x;
}
int Matriz::getf(){
return filas;
}
int Matriz::getc(){
return columnas;
}
int Matriz::SumaTotal(int x, int y)
{int s=0;
for(int i=0;i<x;i++)
{for(int j=0;j<y;j++)
{
	s=s+M[i][j];
}
}
return s;
}
int Matriz::Diagonal(int x, int y)
{int s=0;
for(int i=0;i<x;i++)
{for(int j=0;j<y;j++)
{if(i==j)
{
	s=s+M[i][j];
}
}
}
return s;
}
int Matriz::Factorial(int x, int y)
{int f=1;
for(int i=0;i<x;i++)
{for(int j=0;j<y;j++)
{
	f=f*M[i][j];
}
}
return f;
}
bool Matriz::pares(int x, int y){
for(int i=0;i<x;i++)
{for(int j=0;j<y;j++)
{if(M[i][j]%2==0)
return true;
}
}
}