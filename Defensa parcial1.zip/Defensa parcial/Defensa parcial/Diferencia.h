#pragma once
#define N 50
class Diferencia

{
private:
	int vec[N];
	int tamano;
public:
	Diferencia(void);
	int Get_vec(int pos);
	void Set_vec(int pos, int e);
	int Get_tamano();
	void Set_tamano(int tam);
	int calcular(int tam);
};

