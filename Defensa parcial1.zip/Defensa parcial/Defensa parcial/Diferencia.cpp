#include "StdAfx.h"
#include "Diferencia.h"


Diferencia::Diferencia(void)
{
	vec[N]=0;
	tamano=0;
}
int Diferencia::Get_vec(int pos)
{
return vec[pos];
}
void Diferencia::Set_vec(int pos, int e)
{
vec[pos]=e;
}
int Diferencia::Get_tamano()
{
return tamano;
}
void Diferencia::Set_tamano(int tam)
{
tamano=tam;
}
int Diferencia::calcular(int tam)
{int dif;
dif=vec[0]-vec[1];
for(int i=1;i<tam;i++)
{
	if((vec[i]-vec[i+1])>dif)
	{dif=vec[i]-vec[i-1];}
}
return dif;
}