#pragma once // #(){}[]<>\|/"+
#define Max 25
class Pila
{
private:
int Top;
int P[Max];
int Tamano;
public:
	Pila(void);
	int Get_Tamano();
	void Set_Tamano(int x);
	void Push(int x);
	int Pop();
	bool Full();
	bool Empty();
};

