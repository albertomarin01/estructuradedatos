#include "StdAfx.h"  // #(){}[]<>\|/"+
#include "Pila.h"


Pila::Pila(void)
{
	P[Max]=0;
	Top=-1;
	Tamano=0;
}
int Pila::Get_Tamano()
{
	return Tamano;
}
void Pila::Set_Tamano(int x)
{
	Tamano=x;
}
void Pila::Push(int x)
{
	Top++;
	P[Top]=x;
}
int Pila::Pop()
{int aux;
	aux=P[Top];
	Top--;
	return aux;
}
bool Pila::Full()
{if(Top>=Tamano-1)
    return true;
else
	return false;
}
bool Pila::Empty()
{if(Top == -1)
    return true;
else
	return false;
}