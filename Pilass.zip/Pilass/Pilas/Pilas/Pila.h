#pragma once
#define N 100

class Pila
{
private:
	int top;
	int V[N];
public:
	Pila(void);
	bool push(int e);
	bool empty();
	int pop();
	int peek();
};

