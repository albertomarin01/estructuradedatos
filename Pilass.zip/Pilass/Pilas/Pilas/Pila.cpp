#include "StdAfx.h"
#include "Pila.h"


Pila::Pila(void)
{
	top=-1;
	V[N]=0;
}
bool Pila::push(int e)
{
	if(top>=N-1)
	{return false;}
	else
		{V[++top]=e;
	return true;}
}
bool Pila::empty()
{
	if(top<0)
	{return false;}
	else
	{return true;}
}
int Pila::pop()
{
	if(top<0)
	{return 0;}
	else
	{int x=V[top--];
	return x;}

}
int Pila::peek()
{
	if(top<0)
	{return 0;}
	else
	{int x=V[top];
	return x;}

}